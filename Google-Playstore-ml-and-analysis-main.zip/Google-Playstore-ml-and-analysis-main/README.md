# Google-Playstore-ml-and-analysis
1. Google data analysis.ipynb and analyzer1.ipynb files are intended for all the data analytics


2. ml models-2.ipynb file is applying standard ml algorithms and predicting the details 
3. App recommendation feature here recommends based on all the parameters given any name of an app



4.Use the data sets and make necessary changes in paths of files and run the app with streamlit run file.py command
and you will be able to see the results



#Next goal of project is to deploy it on azure and put up all the analysis charts with description in the file
